import axios from 'axios'

const request =axios.create({
    url: "http://110.40.158.210:8181",
})
export default request