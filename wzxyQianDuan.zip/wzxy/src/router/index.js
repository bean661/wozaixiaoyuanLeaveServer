import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  
]

const router = createRouter({
  //hash模式
  history: createWebHashHistory(),
  routes
})

export default router
