<template>
  <div>
    <el-form ref="form" :model="form" label-width="80px" size="10px">
  <el-form-item label="姓名" >
    <el-input v-model="form.name" style="width: auto;" placeholder="法外狂徒张三"></el-input>
  </el-form-item>
  <el-form-item label="学号">
    <el-input v-model="form.number" style="width: auto;" placeholder="2022202223"></el-input>
  </el-form-item>
  <el-form-item label="手机号">
    <el-input v-model="form.phone" style="width: auto;" placeholder="18899998888"></el-input>
  </el-form-item>
  <el-form-item label="学院">
    <el-input v-model="form.college" style="width: auto;" placeholder="外国语学院"></el-input>
  </el-form-item>
  <el-form-item label="校区">
    <el-input v-model="form.area" style="width: auto;" placeholder="巴黎校区"></el-input>
  </el-form-item>
  <el-form-item label="班级/年级">
    <el-input v-model="form.grade" style="width: auto;" placeholder="本2021级"></el-input>
  </el-form-item>
  <el-form-item label="请假理由">
    <el-input v-model="form.reason" placeholder="里面的人想出去" style="width: auto;" ></el-input>
  </el-form-item>
  <el-form-item label="位置" style="width: auto;">
    <el-input v-model="form.leaveLocation" style="width: auto;" placeholder="陕西省西安市雁塔区xx路888号"></el-input>
  </el-form-item>
  <el-form-item label="辅导员">
    <el-input v-model="form.teacher" style="width: auto;" placeholder="王九"></el-input>
  </el-form-item>
  <el-form-item label="院级老师">
    <el-input v-model="form.clloegeTeacher" style="width: auto;" placeholder="刘二七"></el-input>
  </el-form-item>
  <el-form-item label="校级老师">
    <el-input v-model="form.schoolTeacher" style="width: auto;" placeholder="李三六"></el-input>
  </el-form-item>
  <el-form-item>
    <el-button type="primary" @click="onSubmit">立即创建</el-button>
  </el-form-item>
</el-form>
  </div>
</template>

<style>

</style>
<script>
  import axios from 'axios'
   export default {
    data() {
      return {
        form: {
          name: '',
          number: '',
          phone: '',
          college: '',
          area: '',
          grade: '',
          reason: '',
          teacher: '',
          clloegeTeacher: '',
          schoolTeacher: ''
        }
      }
    },
    methods: {
      onSubmit() {
        axios({
          method:"POST",
          url:"http://127.0.0.1:8181/saveJson",
          data:this.form
        }).then(()=>{
          console.log('111')
        })
        
      }
    }
  }
</script>
